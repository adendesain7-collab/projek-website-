# Graphic Desain Aden

Website marketplace jasa desain digital — HTML5, CSS3, dan JavaScript murni (tanpa framework, tanpa backend). Siap diunggah langsung ke **Netlify** dan diedit sepenuhnya lewat **Acode** di Android.

## Struktur File

```
Graphic-Desain-Aden/
├─ index.html        → seluruh halaman (single page, berpindah tanpa reload)
├─ style.css          → tema Biru Laut Cerah + Glassmorphism
├─ script.js          → semua logika (keranjang, wishlist, admin, dll)
├─ config.js          → SEMUA pengaturan situs (nama, WA, sosial media, pembayaran, admin)
├─ products-data.js   → SEMUA data produk (tambah produk cukup edit file ini)
├─ products.json      → cadangan data produk (format lama, tidak wajib dipakai)
├─ robots.txt
├─ sitemap.xml
└─ assets/
   ├─ banner/         → ganti gambar hero banner di sini
   ├─ products/       → foto produk (opsional, kalau tidak pakai URL online)
   ├─ gallery/
   ├─ payment/        → simpan gambar QRIS di sini (payment/qris.png)
   ├─ testimonial/
   ├─ icons/
   ├─ logo/           → logo.png & favicon.png (opsional — kalau belum diisi, logo bawaan otomatis dipakai)
   └─ background/     → ocean.jpg untuk background blur
```

> **Bisa langsung dibuka.** Cukup klik 2x `index.html` untuk melihat/mengedit websitenya di browser manapun — tidak perlu server atau upload dulu. (Sebelumnya situs memuat data produk lewat `fetch("products.json")`, yang diblokir browser saat file dibuka langsung tanpa server; sekarang data produk ditanam langsung di `products-data.js` supaya tidak lagi butuh server sama sekali.)

## Cara Mengedit

Sekarang **hampir semua konten bisa diubah langsung lewat Dashboard Admin** (Login Admin di navbar), tanpa perlu edit kode sama sekali:

- **Kelola Produk** → tambah, edit (nama/harga/kategori/deskripsi/foto), atau hapus produk.
- **Kelola Banner** → tambah, ganti, atau hapus gambar Hero Banner.
- **Kelola Galeri** → tambah, ganti foto, atau hapus item galeri.
- **Kelola Testimoni** → tambah, edit, atau hapus testimoni pelanggan (foto, nama, komentar, rating).
- **Teks Halaman** → ubah judul Hero, subjudul Hero, dan teks "Tentang Kami".
- **Kelola Pembayaran** → ubah nomor GoPay, DANA, nama pemilik, dan gambar QRIS.
- **Pengaturan** → ubah logo, nama website, tagline, nomor WhatsApp, dan sosial media.

Semua perubahan lewat Dashboard tersimpan permanen di **LocalStorage browser admin** yang dipakai untuk login, dan langsung tampil ke pengunjung yang membuka situs di browser tersebut. Karena ini website statis, perubahan tidak otomatis tersebar ke *semua* pengunjung/perangkat lain — untuk itu tetap edit file sumber berikut secara manual:

- **Ganti nama situs, WhatsApp, sosial media, pembayaran, admin (default awal)** → edit `config.js`.
- **Tambah/ubah/hapus produk (data awal)** → edit `products-data.js` (array `PRODUCTS_DATA`).
- **Ganti banner, logo, QRIS (default awal)** → ganti file gambar di folder `assets/`, atau ubah `DEFAULT_BANNERS` di `script.js`. Kalau folder `assets/logo/` belum diisi `logo.png`/`favicon.png`, website otomatis memakai logo bawaan (tidak akan tampil rusak).
- **Ubah testimoni & galeri (data awal)** → edit array `DEFAULT_TESTIMONIALS` dan `DEFAULT_GALLERY` di `script.js`.
- Login dashboard admin demo: username & password ada di `config.js` (`admin.username` / `admin.password`) — **wajib diganti** sebelum situs dipakai publik.

## Catatan Penting

- Ini adalah **website statis**. Keranjang, wishlist, dan "Pesanan Lokal" di dashboard admin disimpan di **LocalStorage browser pengunjung** — bukan database server. Artinya data pesanan hanya tersimpan di perangkat masing-masing pengunjung, bukan terpusat. Untuk pesanan sungguhan, alur konfirmasi tetap lewat WhatsApp (sesuai desain awal).
- Login admin di sini hanya untuk **demonstrasi frontend**, bukan keamanan tingkat server — jangan gunakan password sensitif.
- Gambar produk/galeri/testimoni memakai placeholder dari `picsum.photos` (bebas lisensi, otomatis tampil) agar website langsung terlihat lengkap. Ganti dengan foto asli kapan saja lewat `products.json` atau folder `assets/`.
- Tidak ada loading screen/preloader — Hero Banner langsung tampil begitu halaman dibuka.

## Deploy ke Netlify

1. Upload seluruh folder `Graphic-Desain-Aden/` (isi foldernya, bukan foldernya sendiri jika diminta "publish directory") ke Netlify — lewat drag-and-drop di dashboard Netlify atau hubungkan repo Git.
2. Tidak perlu build command / publish directory khusus — cukup root folder ini.
3. Selesai, website langsung berjalan tanpa proses build.

## Teknologi

HTML5 · CSS3 · JavaScript ES6 (Vanilla) · Google Fonts (Poppins) · Font Awesome (CDN) — tanpa PHP, MySQL, Node.js, atau framework apa pun.
