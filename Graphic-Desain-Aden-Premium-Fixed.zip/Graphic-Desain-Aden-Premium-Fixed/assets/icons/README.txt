Letakkan gambar untuk folder icons di sini.
