Letakkan gambar untuk folder testimonial di sini.
