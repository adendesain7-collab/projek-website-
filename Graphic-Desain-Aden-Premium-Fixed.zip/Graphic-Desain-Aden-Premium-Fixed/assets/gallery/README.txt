Letakkan gambar untuk folder gallery di sini.
