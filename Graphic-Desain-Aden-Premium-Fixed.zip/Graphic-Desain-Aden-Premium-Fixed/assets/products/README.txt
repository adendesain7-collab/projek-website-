Letakkan gambar untuk folder products di sini.
