/* =========================================================================
   PREMIUM-FX.JS — Efek visual tambahan tema "Blue Neon Cyber Premium"
   File ini HANYA menambah efek tampilan (progress bar, cursor glow,
   partikel cahaya, reveal-on-scroll, ripple tombol, parallax ringan).
   Tidak mengubah/menghapus fungsi apa pun di script.js atau config.js.
   ========================================================================= */
(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }

  ready(function () {
    /* ---------------- 1. SCROLL PROGRESS BAR ---------------- */
    var bar = document.createElement("div");
    bar.id = "scrollProgressBar";
    document.body.appendChild(bar);

    function updateProgress() {
      var h = document.documentElement;
      var scrollTop = h.scrollTop || document.body.scrollTop;
      var scrollH = (h.scrollHeight || document.body.scrollHeight) - h.clientHeight;
      var pct = scrollH > 0 ? (scrollTop / scrollH) * 100 : 0;
      bar.style.width = pct + "%";
    }
    document.addEventListener("scroll", updateProgress, { passive: true });
    updateProgress();

    /* ---------------- 2. CURSOR GLOW (mengikuti pointer, non-touch) ---------------- */
    var isTouch = matchMedia("(pointer: coarse)").matches;
    if (!isTouch) {
      var glow = document.createElement("div");
      glow.id = "cursorGlow";
      document.body.appendChild(glow);
      var gx = window.innerWidth / 2, gy = window.innerHeight / 2;
      var cx = gx, cy = gy;
      document.addEventListener("mousemove", function (e) {
        gx = e.clientX; gy = e.clientY;
      });
      (function animateGlow() {
        cx += (gx - cx) * 0.12;
        cy += (gy - cy) * 0.12;
        glow.style.transform = "translate(" + cx + "px," + cy + "px) translate(-50%,-50%)";
        requestAnimationFrame(animateGlow);
      })();
    }

    /* ---------------- 3. FLOATING LIGHT PARTICLES ---------------- */
    var field = document.createElement("div");
    field.id = "particleField";
    document.body.appendChild(field);
    var particleCount = window.innerWidth < 700 ? 16 : 34;
    for (var i = 0; i < particleCount; i++) {
      var dot = document.createElement("div");
      dot.className = "particle-dot";
      var size = 2 + Math.random() * 3;
      dot.style.width = size + "px";
      dot.style.height = size + "px";
      dot.style.left = Math.random() * 100 + "%";
      dot.style.top = 100 + Math.random() * 20 + "%";
      dot.style.animationDuration = (10 + Math.random() * 14) + "s";
      dot.style.animationDelay = (Math.random() * 14) + "s";
      field.appendChild(dot);
    }

    /* ---------------- 4. REVEAL ON SCROLL (fade + slide up) ---------------- */
    var revealTargets = document.querySelectorAll(
      ".section, .card, .package-card, .testi-card, .quick-cat, .timeline-step, .masonry-item, .about-box, .promo-chip"
    );
    revealTargets.forEach(function (el) {
      el.classList.add("reveal-fx");
    });
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    revealTargets.forEach(function (el) { io.observe(el); });

    /* Jaring pengaman: pastikan konten tidak pernah tersembunyi permanen,
       misalnya saat berpindah halaman (produk/checkout/dashboard) sebelum
       IntersectionObserver sempat mendeteksi elemen yang sedang display:none. */
    function revealAllVisible() {
      document.querySelectorAll(".reveal-fx:not(.in-view)").forEach(function (el) {
        if (el.offsetParent !== null) el.classList.add("in-view");
      });
    }
    document.addEventListener("click", function (e) {
      if (e.target.closest("[data-page], .nav-menu a, .tab-btn, .dash-menu-btn")) {
        setTimeout(revealAllVisible, 60);
      }
    });
    setInterval(revealAllVisible, 1500);

    /* Elemen baru yang muncul belakangan (produk dimuat lewat JS) juga ikut reveal */
    var lateObserver = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        m.addedNodes.forEach(function (node) {
          if (node.nodeType !== 1) return;
          var matches = node.matches && node.matches(
            ".card, .package-card, .testi-card, .quick-cat, .timeline-step, .masonry-item"
          );
          if (matches) {
            node.classList.add("reveal-fx");
            requestAnimationFrame(function () {
              requestAnimationFrame(function () { node.classList.add("in-view"); });
            });
          }
        });
      });
    });
    lateObserver.observe(document.body, { childList: true, subtree: true });

    /* ---------------- 5. RIPPLE EFFECT PADA TOMBOL ---------------- */
    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".btn, .fab, .tab-btn, .page-btn, .quick-cat, .package-badge");
      if (!btn) return;
      var rect = btn.getBoundingClientRect();
      var ripple = document.createElement("span");
      var size = Math.max(rect.width, rect.height);
      ripple.className = "btn-ripple";
      ripple.style.width = ripple.style.height = size + "px";
      ripple.style.left = (e.clientX - rect.left - size / 2) + "px";
      ripple.style.top = (e.clientY - rect.top - size / 2) + "px";
      var prevPosition = getComputedStyle(btn).position;
      if (prevPosition === "static") btn.style.position = "relative";
      btn.style.overflow = btn.style.overflow || "hidden";
      btn.appendChild(ripple);
      setTimeout(function () { ripple.remove(); }, 650);
    });

    /* ---------------- 6. PARALLAX RINGAN PADA HERO ---------------- */
    var hero = document.getElementById("hero");
    if (hero && !isTouch) {
      document.addEventListener("scroll", function () {
        var y = window.scrollY;
        if (y < window.innerHeight * 1.2) {
          hero.style.backgroundPosition = "center " + (y * 0.25) + "px";
        }
      }, { passive: true });
    }

    /* ---------------- 7. LOADING ANIMATION PREMIUM (page load reveal) ---------------- */
    document.documentElement.style.setProperty("--fx-loaded", "1");
    window.addEventListener("load", function () {
      document.body.classList.add("fx-ready");
    });
  });
})();
